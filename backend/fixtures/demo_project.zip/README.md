# E-Commerce
Setup: npm install && npm start