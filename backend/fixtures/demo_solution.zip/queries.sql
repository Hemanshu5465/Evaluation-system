SELECT full_name FROM patient WHERE dob < '2000-01-01';
SELECT p.full_name, d.full_name FROM appointment a JOIN patient p ON p.patient_id=a.patient_id JOIN doctor d ON d.doctor_id=a.doctor_id;
SELECT d.department_id, COUNT(*) c FROM appointment a JOIN doctor d ON d.doctor_id=a.doctor_id GROUP BY d.department_id HAVING COUNT(*) >= 0;