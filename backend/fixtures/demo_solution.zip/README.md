# Hospital DB solution
Assumptions documented.