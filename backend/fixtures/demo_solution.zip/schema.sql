CREATE TABLE department (department_id INTEGER PRIMARY KEY, name TEXT NOT NULL);
CREATE TABLE doctor (doctor_id INTEGER PRIMARY KEY, full_name TEXT NOT NULL, department_id INTEGER REFERENCES department(department_id));
CREATE TABLE patient (patient_id INTEGER PRIMARY KEY, full_name TEXT NOT NULL, dob TEXT);
CREATE TABLE appointment (appointment_id INTEGER PRIMARY KEY, patient_id INTEGER REFERENCES patient(patient_id), doctor_id INTEGER REFERENCES doctor(doctor_id), scheduled_at TEXT, status TEXT);